import MetaTrader5 as mt5
import pandas as pd
import talib

if not mt5.initialize():
    quit()

symbol = "EURUSD"
rates = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_M15, 0, 100)
if rates is None or len(rates) < 50:
    mt5.shutdown()
    quit()

df = pd.DataFrame(rates)
df["time"] = pd.to_datetime(df["time"], unit="s")

open = df["open"].values
high = df["high"].values
low = df["low"].values
close = df["close"].values

signals = []

if talib.CDLDOJI(open, high, low, close)[-1] != 0:
    signals.append("Doji")
if talib.CDLHAMMER(open, high, low, close)[-1] != 0:
    signals.append("Hammer")
if talib.CDLENGULFING(open, high, low, close)[-1] > 0:
    signals.append("Bullish Engulfing")
elif talib.CDLENGULFING(open, high, low, close)[-1] < 0:
    signals.append("Bearish Engulfing")

signal = ", ".join(signals) if signals else "No pattern"

with open("../data/pattern_signal.txt", "w") as f:
    f.write(signal)

print("Detected Patterns:", signal)
mt5.shutdown()
