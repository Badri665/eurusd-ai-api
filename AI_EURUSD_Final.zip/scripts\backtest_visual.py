import MetaTrader5 as mt5
from datetime import datetime, timedelta
import pandas as pd

if not mt5.initialize():
    quit()

symbol = "EURUSD"
rates = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_M15, 0, 100)
if not rates or len(rates) < 30:
    mt5.shutdown()
    quit()

df = pd.DataFrame(rates)
df["time"] = pd.to_datetime(df["time"], unit="s")
df["direction"] = df["close"].diff().apply(lambda x: "BUY" if x > 0 else "SELL")

for i in range(-10, 0):
    t = df["time"].iloc[i]
    price = df["close"].iloc[i]
    signal = df["direction"].iloc[i]
    obj_name = f"BT_{i}"

    future_time = t + timedelta(minutes=15)
    future_price = df["close"].iloc[i+1]

    mt5.chart_object_create(0, obj_name, mt5.OBJ_TREND, 0, t, price, future_time, future_price)
    mt5.chart_object_set_integer(0, obj_name, mt5.OBJPROP_COLOR, mt5.COLOR_LIME if signal == "BUY" else mt5.COLOR_RED)
    mt5.chart_object_set_integer(0, obj_name, mt5.OBJPROP_WIDTH, 1)

print("✅ Visual Backtest drawn")
mt5.shutdown()
