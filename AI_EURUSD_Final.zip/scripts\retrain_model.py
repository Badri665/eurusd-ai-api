import pandas as pd
import pickle
from xgboost import XGBClassifier
from sklearn.model_selection import GridSearchCV

df = pd.read_csv("../data/eurusd_history.csv")
X = df.drop(columns=["target"])
y = df["target"]

params = {
    "max_depth": [3, 4, 5],
    "learning_rate": [0.05, 0.1, 0.2],
    "n_estimators": [50, 100, 150]
}

model = GridSearchCV(XGBClassifier(use_label_encoder=False, eval_metric='logloss'), params, cv=3, n_jobs=-1)
model.fit(X, y)

with open("../models/xgb_eurusd_model.pkl", "wb") as f:
    pickle.dump(model.best_estimator_, f)

print("Model retrained with best parameters:", model.best_params_)
