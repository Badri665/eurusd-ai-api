import MetaTrader5 as mt5
import pandas as pd

if not mt5.initialize():
    quit()

symbol = "EURUSD"
rates = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_M15, 0, 50)
if not rates or len(rates) < 20:
    mt5.shutdown()
    quit()

df = pd.DataFrame(rates)
df["high"] = df["high"].astype(float)
df["low"] = df["low"].astype(float)
df["close"] = df["close"].astype(float)
last_price = df["close"].iloc[-1]
atr = (df["high"] - df["low"]).rolling(window=20).mean().iloc[-1]

sl = round(last_price - atr * 1.5, 5)
tp = round(last_price + atr * 2.0, 5)

with open("../data/sl_tp.txt", "w") as f:
    f.write(f"{sl},{tp}")

print(sl, tp)
mt5.shutdown()
