import MetaTrader5 as mt5
import pandas as pd
from datetime import datetime

lot = 0.1
symbol = "EURUSD"
sl_pips = 20
tp_pips = 30

if not mt5.initialize():
    print("MT5 init failed")
    quit()

signal = ""
try:
    with open("../data/signal.txt", "r") as f:
        signal = f.read().strip()
except:
    print("Signal file missing.")
    mt5.shutdown()
    quit()

price = mt5.symbol_info_tick(symbol).ask if signal == "BUY" else mt5.symbol_info_tick(symbol).bid
sl = price - sl_pips * 0.0001 if signal == "BUY" else price + sl_pips * 0.0001
tp = price + tp_pips * 0.0001 if signal == "BUY" else price - tp_pips * 0.0001
order_type = mt5.ORDER_TYPE_BUY if signal == "BUY" else mt5.ORDER_TYPE_SELL

request = {
    "action": mt5.TRADE_ACTION_DEAL,
    "symbol": symbol,
    "volume": lot,
    "type": order_type,
    "price": price,
    "sl": sl,
    "tp": tp,
    "deviation": 10,
    "magic": 1000,
    "comment": "AI EURUSD Trade",
    "type_time": mt5.ORDER_TIME_GTC,
    "type_filling": mt5.ORDER_FILLING_IOC,
}

result = mt5.order_send(request)
status = "WIN" if result.retcode == 10009 else "LOSS"

log = {
    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M"),
    "signal": signal,
    "result": status,
    "pnl": 25 if status == "WIN" else -20
}

df = pd.DataFrame([log])
try:
    df.to_csv("../data/trade_log.csv", mode='a', index=False, header=False)
except:
    df.to_csv("../data/trade_log.csv", mode='w', index=False, header=True)

print(f"Order: {signal} | Status: {status}")
mt5.shutdown()
