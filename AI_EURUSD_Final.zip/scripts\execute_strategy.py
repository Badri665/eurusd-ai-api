import pandas as pd

log = pd.read_csv("../data/trade_log.csv")
results = log["result"].value_counts()

print("Wins:", results.get("WIN", 0))
print("Losses:", results.get("LOSS", 0))
