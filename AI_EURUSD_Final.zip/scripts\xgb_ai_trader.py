import pandas as pd
import pickle
import MetaTrader5 as mt5

if not mt5.initialize():
    quit()

symbol = "EURUSD"
rates = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_M15, 0, 50)
if rates is None or len(rates) < 3:
    mt5.shutdown()
    quit()

df = pd.DataFrame(rates)
df["time"] = pd.to_datetime(df["time"], unit="s")
df = df[["open", "high", "low", "close"]]
df["target"] = [1 if df["close"].iloc[i+1] > df["close"].iloc[i] else 0 for i in range(len(df)-1)] + [0]

with open("../models/xgb_eurusd_model.pkl", "rb") as f:
    model = pickle.load(f)

X = df.drop(columns=["target"])
latest = X.tail(1)
prediction = model.predict(latest)[0]

with open("../data/signal.txt", "w") as f:
    f.write("BUY" if prediction == 1 else "SELL")

mt5.shutdown()
