import MetaTrader5 as mt5
import pandas as pd

if not mt5.initialize():
    quit()

symbol = "EURUSD"
h1 = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_H1, 0, 100)
d1 = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_D1, 0, 100)

pd.DataFrame(h1).assign(time=lambda x: pd.to_datetime(x["time"], unit="s")).to_csv("../data/history_h1.csv", index=False)
pd.DataFrame(d1).assign(time=lambda x: pd.to_datetime(x["time"], unit="s")).to_csv("../data/history_d1.csv", index=False)

mt5.shutdown()
