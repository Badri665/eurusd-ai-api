import pandas as pd
import lightgbm as lgb
import pickle

df = pd.read_csv("../data/eurusd_history.csv")
X = df.drop(columns=["target"])
y = df["target"]

train_data = lgb.Dataset(X, label=y)
params = {
    "objective": "binary",
    "metric": "binary_logloss",
    "learning_rate": 0.05,
    "verbose": -1
}

model = lgb.train(params, train_data, num_boost_round=100)

with open("../models/lgbm_model.pkl", "wb") as f:
    pickle.dump(model, f)

print("✅ LightGBM model trained and saved.")
