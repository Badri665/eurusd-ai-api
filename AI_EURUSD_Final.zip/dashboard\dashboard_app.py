import streamlit as st
import pandas as pd
import os

st.set_page_config(page_title="AI EUR/USD Dashboard", layout="wide")
st.title("📈 AI EUR/USD Trading Dashboard")

if not os.path.exists("../data/trade_log.csv"):
    st.warning("No trade log found.")
    st.stop()

df = pd.read_csv("../data/trade_log.csv")

total_trades = len(df)
wins = (df["result"] == "WIN").sum()
losses = (df["result"] == "LOSS").sum()
win_rate = (wins / total_trades) * 100 if total_trades else 0
total_pnl = df["pnl"].sum()

col1, col2, col3, col4 = st.columns(4)
col1.metric("Total Trades", total_trades)
col2.metric("Wins", wins)
col3.metric("Losses", losses)
col4.metric("Win Rate", f"{win_rate:.2f}%")

st.subheader("📊 Cumulative PnL")
st.line_chart(df["pnl"].cumsum())

st.subheader("📝 Trade Log")
st.dataframe(df.tail(20), height=400)

st.success("Dashboard updated successfully.")
